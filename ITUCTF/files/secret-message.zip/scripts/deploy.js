const hre = require("hardhat");

async function main() {
  const SecretMessage = await hre.ethers.getContractFactory("SecretMessage");
  const secretMessage = await SecretMessage.deploy();
  await secretMessage.deployed();

  console.log("SecretMessage deployed to:", secretMessage.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  }); 