import socket
from time import sleep

# Tarama yapılacak IP ve port listeleri
ip_list = [
    
    "192.168.100.24",
    "192.0.2.45",
    "198.51.100.23",
    "192.168.56.101",
    "203.0.113.5"
]

port_list = [21, 22, 80, 443, 1337]

def scan(ip, port):
    try:
        sock = socket.socket()
        sock.settimeout(0.5)
        sock.connect((ip, port))
        print(f"[+] {ip}:{port} açık")
    except:
        pass
    finally:
        sock.close()

print("[*] Port taraması başlatılıyor...")
for ip in ip_list:
    for port in port_list:
        scan(ip, port)
        sleep(0.1)  
