const hre = require("hardhat");

async function main() {
  const VulnerableVault = await hre.ethers.getContractFactory("VulnerableVault");
  const vault = await VulnerableVault.deploy();
  await vault.deployed();

  console.log("VulnerableVault deployed to:", vault.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  }); 